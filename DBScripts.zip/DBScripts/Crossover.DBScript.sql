-- STEP 1:
CREATE DATABASE StockExchange;
GO
  
-- STEP 2:
USE StockExchange;
GO

-- STEP 3:

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

-- =============================================
-- Author:		<Author,Totada >
-- Create date: <Create Date, 13-Apr-2017>
-- Description:	<Description, users table creation>
-- =============================================
CREATE TABLE [dbo].[users](
	[userid] [int] IDENTITY(1,1) NOT NULL,
	[firstname] [varchar](50) NULL,
	[lastname] [varchar](50) NULL,
	[username] [varchar](50) NULL,
	[password] [varchar](50) NULL,
 CONSTRAINT [PK_users] PRIMARY KEY CLUSTERED 
(
	[userid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


-- STEP 4: 

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

-- =============================================
-- Author:		<Author,Totada >
-- Create date: <Create Date, 13-Apr-2017>
-- Description:	<Description, stocks table creation>
-- =============================================
CREATE TABLE [dbo].[stocks](
	[stockid] [int] IDENTITY(1,1) NOT NULL,
	[stockname] [varchar](100) NULL,
	[stockcode] [varchar](100) NULL,
 CONSTRAINT [PK_stocks] PRIMARY KEY CLUSTERED 
(
	[stockid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


-- STEP 5: 

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,Totada >
-- Create date: <Create Date, 13-Apr-2017>
-- Description:	<Description, userstocks table creation>
-- =============================================
CREATE TABLE [dbo].[userstocks](
	[userstockid] [int] IDENTITY(1,1) NOT NULL,
	[userid] [int] NULL,
	[stockid] [int] NULL
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[userstocks]  WITH CHECK ADD  CONSTRAINT [FK_userstocks_stocks] FOREIGN KEY([stockid])
REFERENCES [dbo].[stocks] ([stockid])
GO

ALTER TABLE [dbo].[userstocks] CHECK CONSTRAINT [FK_userstocks_stocks]
GO


-- STEP 6: 
-- =============================================
-- Author:		<Author,Totada >
-- Create date: <Create Date, 13-Apr-2017>
-- Description:	<Description, Master data list>
-- =============================================
INSERT INTO STOCKS ( STOCKNAME, STOCKCODE )
VALUES
('BlockBook ATS', 'BBK' ),
('C2 Options Exchange', 'C2OX' ),
('Chicago Stock Exchange', 'MW'),
('Chi-X Australia', 'CHA' ),
('Kabu.com PTS', 'KAB'),
('Korean Futures Exchange', 'KFE' ),
('Pink Sheets (National Quotation Bureau)', 'PNK' ),
('Russian Trading System', 'RTS' )

GO
-- STEP 7: 

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,Totada >
-- Create date: <Create Date, 13-Apr-2017>
-- Description:	<Description, To check authentication>
-- =============================================
 
CREATE PROCEDURE [dbo].[spCheckAuthentication]
	-- Add the parameters for the stored procedure here	
	@username varchar(50),
	@password varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF EXISTS 
	(
		SELECT *
		FROM users u
		WHERE u.username = @username
			AND u.[password] = @password
	)
	BEGIN
		SELECT * from users where username = @username;
	END
    ELSE
	BEGIN 
		RAISERROR (15600,-1,-1, 'Invalid User.');  
 
	END
END
GO


-- STEP 8: 

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,Totada >
-- Create date: <Create Date, 13-Apr-2017>
-- Description:	<Description, To create new account>
-- =============================================
CREATE PROCEDURE [dbo].[spCreateNewAccount]
	-- Add the parameters for the stored procedure here
	@username varchar(50),
	@password varchar(50),
	@firstname varchar(50),
	@lastname varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @userId int

	SET @userId = -1

	IF NOT EXISTS 
	(
	   SELECT username
	   FROM users
	   WHERE username = @username 
	)
		BEGIN
			INSERT INTO users
			(
				username,
				[password],
				firstname,
				lastname
			)
			Values (
				@username,
				@password,
				@firstname,
				@lastname
			)

			SET @userId = SCOPE_IDENTITY();
		END

		SELECT @userId
END
GO