﻿using CrossOVer.DataAccessTier.DAProducts;
using System;

namespace CrossOVer.DataAccessTier.DAFactory
{
    public class DBFactory : DataAccessFactory
    {
        public override DataAccessBase GetDataAccessLayer(DataProviderType dataProviderType)
        {
            switch (dataProviderType)
            {
                case DataProviderType.Access:
                case DataProviderType.OleDb:
                    throw new ArgumentException("Feature is not Implemented for Access and OLEDB provider type(s).");
                case DataProviderType.Sql:
                    return new SQLDataAccess("");

                default:
                    throw new ArgumentException("Invalid DataAccessLayer provider type.");
            }
        }
    }
}
