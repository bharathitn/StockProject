﻿using CrossOVer.DataAccessTier.DAProducts;

namespace CrossOVer.DataAccessTier.DAFactory
{
    public enum DataProviderType
    {
        Access,
        OleDb,
        Sql
    }

    public abstract class DataAccessFactory
    {
        public abstract DataAccessBase GetDataAccessLayer(DataProviderType dataProviderType);
    }
}
