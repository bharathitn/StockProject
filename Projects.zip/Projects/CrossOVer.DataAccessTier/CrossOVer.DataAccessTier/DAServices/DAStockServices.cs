﻿using CrossOver.BusinessObjects;
using CrossOVer.DataAccessTier.DAFactory;
using CrossOVer.DataAccessTier.DAProducts;
using System;
using System.Collections.Generic;
using System.Data;

namespace CrossOVer.DataAccessTier.DAServices
{
    public class DAStockServices
    {
        DBFactory dbFactory = null;
        DataAccessBase daBase = null;

        public DAStockServices()
        {
            try
            {
                // instantiate the dbfactory and dataAccessBase. 
                dbFactory = new DBFactory();
                daBase = dbFactory.GetDataAccessLayer(DataProviderType.Sql);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// To get all the stocks for the given user. 
        /// </summary>
        /// <param name="currentUserid"></param>
        /// <returns></returns>
        public DataSet GetStocksForGivenUser(int currentUserid)
        {
            DataSet dsSource = null;
            try
            {
                dsSource = new DataSet();

                // Command Text
                string commandText = string.Format(@"IF Exists (select  us.stockid from users  u join userstocks us  ON us.userid=u.userid inner join stocks  s on s.stockid = us.stockid where u.userid = {0})
                                    BEGIN
	                                    select  us.stockid, s.stockname, s.stockcode from users  u join userstocks us  ON us.userid=u.userid inner join stocks  s on s.stockid = us.stockid where u.userid = {0}
                                    END
                                    ELSE
                                    BEGIN
	                                    select 0 as StockId, 'No records found' as StockName
                                    END", currentUserid);

                return daBase.GetDataSet(commandText, System.Data.CommandType.Text, null);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// To get all the stocks.
        /// </summary>
        /// <returns></returns>
        public List<Stocks> GetAllStocks()
        {
            List<Stocks> stocks = null;
            try
            {
                stocks = new List<Stocks>();
                DataSet dsSource = new DataSet();
                Stocks stock = null;
                // Command Text
                string commandText = "SELECT stockid, stockname, stockcode   FROM [stocks]  ";

                // Fill the data set
                dsSource = daBase.GetDataSet(commandText, CommandType.Text);
                foreach (System.Data.DataRow row in dsSource.Tables[0].Rows)
                {
                    stock = new Stocks();
                    stock.Id = Convert.ToInt32(row["stockid"]);
                    stock.StockName = Convert.ToString(row["stockname"]);
                    stock.StockCode = Convert.ToString(row["stockcode"]);
                    stocks.Add(stock);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return stocks;
        }

        /// <summary>
        /// Save the stocks that the given user has collected. 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="stockId"></param>
        /// <returns></returns>
        public int SaveUserStocks(int userId, int stockId)
        {
            Int32 intId = 0;
            try
            {
                // Command Text to check if the user is already mapped to stock. 
                string commandText = string.Format("select userstockid from userstocks where userid= {0} and stockid = {1} ", userId, stockId);
                // Fill the data set
                object result = daBase.ExecuteScalar(commandText, CommandType.Text, null);

                // if no mapping, map user to the given stock. 
                if (result == null)
                {
                    commandText = "INSERT INTO   userstocks (userid, stockid) VALUES ( " + userId + "  ,  " + stockId + " ) ";
                    // Fill the data set
                    intId = daBase.ExecuteNonQuery(commandText, CommandType.Text, null);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return intId;
        }

        /// <summary>
        /// Delete the user stock. 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="stockId"></param>
        /// <returns></returns>
        public bool DeleteUserStock(int userId, int stockId)
        {
            Int32 intId = 0;
            // Command Text
            string commandText = "delete from userstocks where userId = " + userId + "and stockId = " + stockId;

            // Fill the data set
            intId = daBase.ExecuteNonQuery(commandText, CommandType.Text, null);

            return true;
        }
    }
}
