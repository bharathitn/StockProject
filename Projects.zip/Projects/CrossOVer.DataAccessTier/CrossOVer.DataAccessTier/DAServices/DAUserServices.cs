﻿using CrossOver.BusinessObjects;
using CrossOVer.DataAccessTier.DAFactory;
using CrossOVer.DataAccessTier.DAProducts;
using System;
using System.Collections.Generic;
using System.Data;

namespace CrossOVer.DataAccessTier.DAServices
{
    public class DAUserServices
    {
        DBFactory dbFactory = null;
        DataAccessBase daBase = null;

        public DAUserServices()
        {
            try
            {
                // instantiate the dbfactory and the dabase.
                dbFactory = new DBFactory();
                daBase = dbFactory.GetDataAccessLayer(DataProviderType.Sql);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// To get all the users. 
        /// </summary>
        /// <returns></returns>
        public DataSet GetUsers()
        {
            DataSet dsSource = null;
            try
            {
                dsSource = new DataSet();
                // Command Text
                string commandText = "select * from [users]  ";

                // Fill the data set
                dsSource = daBase.GetDataSet(commandText, CommandType.Text);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsSource;
        }

        /// <summary>
        /// Register the new user. 
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public string RegisterUsers(Users user)
        {
            string newAccountDetails = string.Empty;

            try
            {
                // list of sql parameters
                List<IDbDataParameter> sParams = new List<IDbDataParameter>();
                IDbDataParameter spUsername = daBase.CreateParameter("username", user.UserName, DbType.String);
                IDbDataParameter spPassword = daBase.CreateParameter("password", user.Password, DbType.String);
                IDbDataParameter spFirstname = daBase.CreateParameter("firstname", user.Firstname, DbType.String);
                IDbDataParameter spLastname = daBase.CreateParameter("lastname", user.Lastname, DbType.String);

                // Add list of sql parameters to pass to the procedures
                sParams.Add(spUsername);
                sParams.Add(spPassword);
                sParams.Add(spFirstname);
                sParams.Add(spLastname);

                // Fill the data set
                object objResult = daBase.ExecuteScalar("spCreateNewAccount", System.Data.CommandType.StoredProcedure, sParams);

                if (Convert.ToInt32(objResult) == -1)
                {
                    newAccountDetails = "User already exists.";
                }
                else
                {
                    newAccountDetails = "Registration successful";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return newAccountDetails;
        }

        /// <summary>
        /// To authenticate the user. 
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public DataSet AuthenticateUser(Users user)
        {
            try
            {
                // list of sql parameters
                List<IDbDataParameter> sParams = new List<IDbDataParameter>();
                IDbDataParameter spUsername = daBase.CreateParameter("username", user.UserName, DbType.String);
                IDbDataParameter spPassword = daBase.CreateParameter("password", user.Password, DbType.String);

                // Add list of sql parameters to pass to the procedures
                sParams.Add(spUsername);
                sParams.Add(spPassword);

                return daBase.GetDataSet("spCheckAuthentication", System.Data.CommandType.StoredProcedure, sParams);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Delete the selected user. 
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public string DeleteUsers(int userid)
        {
            string userStatus = string.Empty;

            try
            {
                // Fill the data set
                int objResult = daBase.ExecuteNonQuery("delete from users where userid = " + userid, System.Data.CommandType.Text, null);

                if (objResult == -1)
                {
                    userStatus = "User not found.";
                }
                else
                {
                    userStatus = "User deleted successfully";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return userStatus;
        }

        /// <summary>
        /// Get the userid by username and password. 
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public int GetUserId(string userName, string password)
        {
            int userId = -1;

            try
            {
                // Fill the data set
                DataSet dsSource = daBase.GetDataSet("select * from users where username='" + userName + "' and password ='" + password + "'", System.Data.CommandType.Text);

                if (dsSource != null
                    && dsSource.Tables.Count > 0
                    && dsSource.Tables[0].Rows.Count > 0)
                {
                    userId = Convert.ToInt32(dsSource.Tables[0].Rows[0]["userid"]);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return userId;
        }
    }
}
