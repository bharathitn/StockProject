﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace CrossOVer.DataAccessTier.DAProducts
{
    public class SQLDataAccess : DataAccessBase
    {
        public SQLDataAccess(string connectionString)
        {
            this.ConnectionString = ConfigurationManager.AppSettings["ConnectionStringValue"];
        }

        // DALBaseClass Members
        public override IDbConnection GetDataProviderConnection()
        {
            return new SqlConnection();
        }

        public override IDbCommand GeDataProviderCommand()
        {
            return new SqlCommand();
        }

        public override IDbDataAdapter GetDataProviderDataAdapter()
        {
            return new SqlDataAdapter();
        }


        #region New Dataaccess methods
        /// <summary>
        /// To save the value in to data set. 
        /// </summary>
        /// <param name="spName"></param>
        /// <param name="cmdType"></param>
        /// <param name="sParams"></param>
        /// <returns></returns>
        public override DataSet GetDataSet(string spName, CommandType cmdType, List<IDbDataParameter> sParams)
        {
            DataSet dsSource = null;
            try
            {
                dsSource = new DataSet();

                using (SqlConnection sqlConnectionObj = new SqlConnection(this.ConnectionString))
                {
                    sqlConnectionObj.Open();

                    using (SqlCommand SqlCommandObj = new SqlCommand())
                    {
                        SqlCommandObj.Connection = sqlConnectionObj;
                        SqlCommandObj.CommandType = cmdType;
                        SqlCommandObj.CommandText = spName;

                        if (sParams != null)
                        {
                            SqlCommandObj.Parameters.AddRange(sParams.ToArray());
                        }

                        using (SqlDataAdapter sqlDataAdapterObj = new SqlDataAdapter())
                        {
                            sqlDataAdapterObj.SelectCommand = SqlCommandObj;
                            sqlDataAdapterObj.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                            sqlDataAdapterObj.Fill(dsSource);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dsSource;
        }

        /// <summary>
        /// To save the value in to data set. 
        /// </summary>
        /// <param name="sqlQuery"></param>
        /// <param name="cmdType"></param>
        /// <returns></returns>
        public override DataSet GetDataSet(string sqlQuery, CommandType cmdType)
        {
            try
            {
                return this.GetDataSet(sqlQuery, cmdType, null);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// To execute the scalar query type. 
        /// </summary>
        /// <param name="spName"></param>
        /// <param name="cmdType"></param>
        /// <param name="sParams"></param>
        /// <returns></returns>
        public override object ExecuteScalar(string spName, CommandType cmdType, List<IDbDataParameter> sParams)
        {
            object result = 0;

            try
            {
                using (SqlConnection sqlConnectionObj = new SqlConnection(this.ConnectionString))
                {
                    sqlConnectionObj.Open();

                    using (SqlCommand SqlCommandObj = new SqlCommand())
                    {
                        SqlCommandObj.Connection = sqlConnectionObj;
                        SqlCommandObj.CommandType = cmdType;
                        SqlCommandObj.CommandText = spName;

                        if (sParams != null)
                        {
                            SqlCommandObj.Parameters.AddRange(sParams.ToArray());
                        }

                        result = SqlCommandObj.ExecuteScalar();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        /// <summary>
        /// To execute non query type
        /// </summary>
        /// <param name="spName"></param>
        /// <param name="cmdType"></param>
        /// <param name="sParams"></param>
        /// <returns></returns>
        public override int ExecuteNonQuery(string spName, CommandType cmdType, List<IDbDataParameter> sParams)
        {
            int result = 0;
            try
            {
                using (SqlConnection sqlConnectionObj = new SqlConnection(this.ConnectionString))
                {
                    sqlConnectionObj.Open();

                    using (SqlCommand SqlCommandObj = new SqlCommand())
                    {
                        SqlCommandObj.Connection = sqlConnectionObj;
                        SqlCommandObj.CommandType = cmdType;
                        SqlCommandObj.CommandText = spName;

                        if (sParams != null)
                        {
                            SqlCommandObj.Parameters.AddRange(sParams.ToArray());
                        }

                        result = SqlCommandObj.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        public override int ExecuteNonQuery(string sqlQuery, CommandType cmdType)
        {
            return ExecuteNonQuery(sqlQuery, CommandType.Text);
        }
        #endregion New Dataaccess methods

        #region Generate Sql Parameters

        /// <summary>
        ///     Create sql parameter with required parameters
        /// </summary>
        /// <param name="paramName">parameter name</param>
        /// <param name="paramValue">parameter value</param>
        /// <param name="sqlDbTypeSource">sql data type</param>
        /// <returns>returns sql parameter object</returns>
        public override IDbDataParameter CreateParameter(string paramName, object paramValue, DbType dbTypeSource)
        {
            try
            {
                return this.CreateParameter(paramName, paramValue, dbTypeSource, 0, ParameterDirection.Input);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        ///     Create sql parameter with required parameters
        /// </summary>
        /// <param name="paramName">parameter name</param>
        /// <param name="paramValue">parameter value</param>
        /// <param name="sqlDbTypeSource">sql data type</param>
        /// <param name="size">size</param>
        /// <returns>returns sql parameter object</returns>
        public override IDbDataParameter CreateParameter(string paramName, object paramValue, DbType dbTypeSource, int size)
        {
            try
            {
                return this.CreateParameter(paramName, paramValue, dbTypeSource, size, ParameterDirection.Input);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        ///     Create sql parameter with required parameters
        /// </summary>
        /// <param name="paramName">parameter name</param>
        /// <param name="paramValue">parameter value</param>
        /// <param name="sqlDbTypeSource">sql data type</param>
        /// <param name="size">size</param>
        /// <param name="paramDirection">parameter direction</param>
        /// <returns>returns sql parameter object</returns>
        public override IDbDataParameter CreateParameter(string paramName, object paramValue, DbType dbTypeSource, int size, ParameterDirection paramDirection)
        {
            IDbDataParameter sParamSource = null;
            try
            {
                sParamSource = new SqlParameter();
                sParamSource.ParameterName = string.Format("@{0}", paramName);
                sParamSource.DbType = dbTypeSource;
                sParamSource.Size = size;
                sParamSource.Direction = ParameterDirection.Input;
                sParamSource.Value = paramValue;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return sParamSource;
        }

        #endregion Generate Sql Parameters
    }
}
