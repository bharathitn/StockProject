﻿using System;
using System.Collections.Generic;
using System.Data;

namespace CrossOVer.DataAccessTier.DAProducts
{
    public abstract class DataAccessBase
    {
        private string connectionString;
        private IDbConnection connection;
        private IDbCommand command;
        private IDbTransaction transaction;

        /// <summary>
        /// Connection string property
        /// </summary>
        public string ConnectionString
        {
            get
            {
                // check if connectionString not empty or null or spaces
                if (string.IsNullOrEmpty(connectionString)
                    || connectionString.Trim().Length == 0)
                {
                    // throw argument exception
                    throw new ArgumentException("Invalid database connection string.");
                }

                // return connection string
                return connectionString;
            }
            set
            {
                connectionString = value;
            }
        }

        protected DataAccessBase()
        {
        }

        public abstract IDbConnection GetDataProviderConnection();

        public abstract IDbCommand GeDataProviderCommand();

        public abstract IDbDataAdapter GetDataProviderDataAdapter();

        #region Database Transaction

        public string OpenConnection()
        {
            string Response = string.Empty;
            try
            {
                connection = GetDataProviderConnection(); // instantiate a connection object
                //connection.ConnectionString = this.ConnectionString;
                //connection.Open(); // open connection
                Response = ((System.Reflection.MemberInfo)(connection.GetType())).Name + "Open Successfully";
            }
            catch
            {
                connection.Close();
                Response = "Unable to Open " +
                           ((System.Reflection.MemberInfo)(connection.GetType())).Name;
            }
            return Response;
        }

        #endregion

        #region New Dataaccess methods
        public abstract DataSet GetDataSet(string spName, CommandType cmdType, List<IDbDataParameter> sParams);
        public abstract DataSet GetDataSet(string sqlQuery, CommandType cmdType);
        public abstract object ExecuteScalar(string spName, CommandType cmdType, List<IDbDataParameter> sParams);
        public abstract int ExecuteNonQuery(string spName, CommandType cmdType, List<IDbDataParameter> sParams);
        public abstract int ExecuteNonQuery(string sqlQuery, CommandType cmdType);
        #endregion New Dataaccess methods

        #region Generate Sql Parameters

        /// <summary>
        ///     Create sql parameter with required parameters
        /// </summary>
        /// <param name="paramName">parameter name</param>
        /// <param name="paramValue">parameter value</param>
        /// <param name="sqlDbTypeSource">sql data type</param>
        /// <returns>returns sql parameter object</returns>
        public abstract IDbDataParameter CreateParameter(string paramName, object paramValue, DbType sqlDbTypeSource);

        /// <summary>
        ///     Create sql parameter with required parameters
        /// </summary>
        /// <param name="paramName">parameter name</param>
        /// <param name="paramValue">parameter value</param>
        /// <param name="sqlDbTypeSource">sql data type</param>
        /// <param name="size">size</param>
        /// <returns>returns sql parameter object</returns>
        public abstract IDbDataParameter CreateParameter(string paramName, object paramValue, DbType sqlDbTypeSource, int size);

        /// <summary>
        ///     Create sql parameter with required parameters
        /// </summary>
        /// <param name="paramName">parameter name</param>
        /// <param name="paramValue">parameter value</param>
        /// <param name="sqlDbTypeSource">sql data type</param>
        /// <param name="size">size</param>
        /// <param name="paramDirection">parameter direction</param>
        /// <returns>returns sql parameter object</returns>
        public abstract IDbDataParameter CreateParameter(string paramName, object paramValue, DbType sqlDbTypeSource, int size, ParameterDirection paramDirection);
        
        #endregion Generate Sql Parameters
    }
}
