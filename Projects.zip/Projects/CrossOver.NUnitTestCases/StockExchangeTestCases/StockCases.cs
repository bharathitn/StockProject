﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using CrossOver.BusinessTier;

namespace StockExchange.TestCases
{
    [TestFixture]
    public class StockCases
    {
        [TestCase]
        public void GetAllStocks()
        {
            List<CrossOver.BusinessObjects.Stocks> stocks = null;
            try
            {
                // create user service object. 
                BStock bStock = new BStock();

                // Get all stocks. 
                stocks = bStock.GetAllStocks();
                Assert.AreEqual(8, stocks.Count);
            }
            catch (Exception ex)
            {
                ErrorLogging.LogMessages(ex);
            }
        }

        [TestCase]
        public void DeleteUserStock()
        { 
            try
            {
                // create user service object. 
                BStock bStock = new BStock();

                bool status = bStock.DeleteUserStock(3, 4);
                if (status)
                    Assert.AreEqual(true, status);
                else
                    Assert.AreNotEqual(true, status);

            }
            catch (Exception ex)
            {
                ErrorLogging.LogMessages(ex);
            }
        }

        [TestCase]
        public void SaveUserStocks()
        {
            try
            {
                // create user service object. 
                BStock bStock = new BStock();

                int status = bStock.SaveUserStocks(3, 8);

                Assert.AreNotEqual(1, status);
            }
            catch (Exception ex)
            {
                ErrorLogging.LogMessages(ex);
            }
        }
    }
}
