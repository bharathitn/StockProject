﻿using NUnit.Framework;
using CrossOver.BusinessTier;
using System.Data;
using CrossOver.BusinessObjects;
using System;

namespace StockExchange.TestCases
{
    [TestFixture]
    public class UserCases
    {
        [TestCase]
        public void AuthenticateUser()
        {
            try
            {
                // create user service object. 
                BUsers bUsers = new BUsers();

                Users user = new Users();
                user.Firstname = "tnb";
                user.Lastname = "tnb";
                user.UserName = "tnb";
                user.Password = "tnb";

                string strResult = bUsers.RegisterUsers(user);

                //Function to authenticate user. 
                DataSet dsSource = bUsers.AuthenticateUser(user);

                if (dsSource != null
                       && dsSource.Tables.Count > 0
                       && dsSource.Tables[0].Rows.Count > 0)
                {
                    Assert.AreEqual(1, dsSource.Tables[0].Rows.Count);
                }

                //Once the user is authenticated, fetch the user id for the user tnb. 
                user.Id = bUsers.GetUserId(user);

                // delete "tnb" user. 
                bUsers.DeleteUser(user);
            }
            catch (Exception ex)
            {
                ErrorLogging.LogMessages(ex);
            }
        }

        [TestCase]
        public void Registeruser()
        {
            try
            {
                Users user = new Users();
                user.Firstname = "First Dummy";
                user.Lastname = "Last Dummy";
                user.UserName = "Dummy1";
                user.Password = "Dummy1";

                BUsers bUsers = new BUsers();
                string strResult = bUsers.RegisterUsers(user);

                if (strResult.Equals("User already exists."))
                {
                    Assert.AreSame("User already exists.", strResult);
                }
                else
                {
                    Assert.AreSame("Registration successful", strResult);
                }
            }
            catch (Exception ex)
            {
                ErrorLogging.LogMessages(ex);
            }
        }

        [TestCase]
        public void GetUsersCount()
        {
            try
            {
                BUsers bUsers = new BUsers();
                DataSet dataSet = bUsers.GetUsers();
                int count = dataSet.Tables[0].Rows.Count;
                if (count >= 1)
                {
                    Assert.GreaterOrEqual(count, 1);
                }
            }
            catch (Exception ex)
            {
                ErrorLogging.LogMessages(ex);
            }
        }
    }
}
