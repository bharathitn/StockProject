﻿using CrossOver.BusinessObjects;
using CrossOver.BusinessTier;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Summary description for RateService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class RateService : System.Web.Services.WebService {

    public RateService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    public bool CheckAuthentication(string usersData)
    {
        // deserialize the user object
        Users user = CommonUtilities.DeSerialzeObject<Users>(usersData);

        // instantiate the dataaccess service
        BUsers busers = new BUsers();

        // chck authenictaion for the user
        DataSet dsSource = busers.AuthenticateUser(user);

        // check if ataset is not null and has some rows
        if (dsSource != null
            && dsSource.Tables.Count > 0
            && dsSource.Tables[0].Rows.Count > 0)
        {
            // user authenticated return true
            return true;
        }
        else
        {
            // user authenticated return true
            return false;
        }
    }

    [WebMethod]
    public DataSet GetUserStockPrices(string usersData)
    {
        DataSet dsSource = new DataSet();

        try
        {
            Users user = CommonUtilities.DeSerialzeObject<Users>(usersData);

            if (this.CheckAuthentication(usersData))
            {
                BStock bstock = new BStock();
                dsSource = bstock.GetStocksForGivenUser(user.Id);

                if (dsSource != null
                    && dsSource.Tables.Count > 0)
                {
                    dsSource.Tables[0].Columns.Add(new DataColumn("StockPrice", typeof(string)));
                    foreach (DataRow drSource in dsSource.Tables[0].Rows)
                    {
                        drSource["StockPrice"] = GetRandomPrice();
                        System.Threading.Thread.Sleep(1000);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return dsSource;
    }
    
    /// <summary>
    /// Get random number using random method.  
    /// </summary>
    /// <returns></returns>
    public string GetRandomPrice()
    {
        string rate = "0.0";

        Random randomNumberGenrator = new Random();
        double randomPrice = Convert.ToDouble(randomNumberGenrator.Next(1000)) + (double)1 / (Convert.ToDouble(randomNumberGenrator.Next(10)) + (double)1);

        rate = randomPrice.ToString("###.##");

        return rate;
    }  
}
