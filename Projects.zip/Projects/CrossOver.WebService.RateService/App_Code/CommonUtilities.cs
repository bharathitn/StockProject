﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

/// <summary>
/// Summary description for CommonUtilities
/// </summary>
public class CommonUtilities
{
	public CommonUtilities()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public static string SerialzeObject<T>(T objectToSerialze) where T : class
    {
        string serialzedContent = string.Empty;

        JavaScriptSerializer jsonSerializer = new JavaScriptSerializer();

        serialzedContent = jsonSerializer.Serialize(objectToSerialze);

        return serialzedContent;
    }

    public static T DeSerialzeObject<T>(string textToDeSerialze) where T : class
    {
        T deserialze = (T)Activator.CreateInstance(typeof(T));

        JavaScriptSerializer jsonSerializer = new JavaScriptSerializer();

        deserialze = jsonSerializer.Deserialize<T>(textToDeSerialze);

        return deserialze;
    }
}