﻿using System;

namespace CrossOver.BusinessObjects
{
    /*******************************************************************************************************************
    * Created By:: Totada
    * Create Date:: 14th April
    * Last Modified By: Totada 
    * Puropose:: Stock class 
    *
    *******************************************************************************************************************/


    [Serializable]
    public class Stocks
    {
        public Stocks()
        {
        }

        public Int32 Id { get; set; }
        public string StockName { get; set; }
        public string StockCode { get; set; }
    }
}
