﻿using CrossOver.BusinessObjects;
using CrossOver.BusinessTier;
using System;
using System.Data;
using System.Web.Security;
using System.Web.UI;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    /// <summary>
    /// To validate the logged in user. 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            if ((Convert.ToString(txtUserName.Text.Trim()) != "") 
                && (Convert.ToString(txtPassword.Text.Trim()) != ""))
            {
                Users user = new Users();
                user.Password = txtPassword.Text.Trim();
                user.UserName = txtUserName.Text.Trim();

                // service to authenticate the user.
                BUsers userService = new BUsers();
                DataSet dsSource = userService.AuthenticateUser(user);

                if (dsSource != null
                    && dsSource.Tables.Count > 0
                    && dsSource.Tables[0].Rows.Count > 0)
                {
                    // Save the complete details of the logged in user into the user object. 
                    Users userObject = new Users();
                    userObject.Id = Convert.ToInt32(dsSource.Tables[0].Rows[0]["userid"]);
                    userObject.Firstname = dsSource.Tables[0].Rows[0]["firstname"].ToString();
                    userObject.Lastname = dsSource.Tables[0].Rows[0]["lastname"].ToString();
                    userObject.UserName = dsSource.Tables[0].Rows[0]["username"].ToString();
                    userObject.Password = dsSource.Tables[0].Rows[0]["password"].ToString();

                    // Save the user object into the session. 
                    Session["User"] = userObject;
                    FormsAuthentication.RedirectFromLoginPage(txtUserName.Text.Trim(), false);

                    // if the logged in user is validated successfully, then redirect to the home page.
                    Response.Redirect("~/View/Home.aspx", false);
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "ValidateUser", "javascript:DisplayMessage1('Invalid User! try again.', true, true);", true);
                }
            }
        }
        catch (Exception ex)
        {
            // if the user is invalid display message to the user
            if (ex.Message.Contains("Invalid User"))
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ValidateUser", "javascript:DisplayMessage1('Invalid User! try again.', true, true);", true);
            }
            else
            {
                // log the error message
                ErrorLogging.LogMessages(ex);
            }
        }
    }
}