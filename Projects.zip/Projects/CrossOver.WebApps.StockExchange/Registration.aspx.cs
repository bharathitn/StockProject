﻿using CrossOver.BusinessObjects;
using CrossOver.BusinessTier;
using System;

public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    /// <summary>
    /// Function to register new user. 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnResiter_Click(object sender, EventArgs e)
    {
        try
        {
            if ((Convert.ToString(txtUserName.Text.Trim()) != "")
                && (Convert.ToString(txtFirstName.Text.Trim()) != "")
                && (Convert.ToString(txtPassword.Text.Trim()) != ""))
            {
                // Save the new registered data into the user object. 
                Users newUser = new Users();
                newUser.Firstname = txtFirstName.Text.Trim();
                newUser.Lastname = txtLastName.Text.Trim();
                newUser.Password = txtPassword.Text.Trim();
                newUser.UserName = txtUserName.Text.Trim();

                BUsers userService = new BUsers();

                //if registerStatusis true, registration successful. 
                string registerStatus = userService.RegisterUsers(newUser);

                if (registerStatus.Equals("Registration successful"))
                {
                    // if registration successful, then display the message accordinly. 
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "ValidateUser", "javascript:DisplayMessage1('Registration successful.', true, false);", true);
                    txtFirstName.Text = "";
                    txtLastName.Text = "";
                    txtPassword.Text = "";
                    txtUserName.Text = "";

                    //Response.Redirect("~/Login.aspx?reg=1");
                }
                else
                {
                    //lblErrorMsg.Text = registerStatus;
                    //lblErrorMsg.Visible = true;
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLogging.LogMessages(ex);
        }
    }
}