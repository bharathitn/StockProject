﻿using CrossOver.BusinessObjects;
using CrossOver.BusinessTier;
using System;
using System.Data;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // invoke bind stocks. To bind data to grid view. 
            BindStocks();
        }
    }

    /// <summary>
    /// Bind stock details to grid view. 
    /// </summary>
    private void BindStocks()
    {
        try
        {
            // populate stocks details from database. 
            DataSet dsSource = PopulateStocksForUser();

            // Bind the stock details to gridview. 
            if (dsSource != null
                && dsSource.Tables.Count > 0
                && dsSource.Tables[0].Rows.Count > 0)
            {
                if (!dsSource.Tables[0].Rows[0]["StockName"].ToString().Equals("No records found"))
                {
                    gvStocks.DataSource = dsSource.Tables[0];
                    gvStocks.DataBind();
                }
                else
                {
                    DataTable dt = new DataTable();
                    dt.Columns.Add(new DataColumn("StockId", typeof(Int32)));
                    dt.Columns.Add(new DataColumn("StockName", typeof(string)));
                    dt.Columns.Add(new DataColumn("StockCode", typeof(string)));
                    dt.Rows.Add(dt.NewRow());
                    gvStocks.DataSource = dt;
                    gvStocks.DataBind();
                    int columncount = gvStocks.Rows[0].Cells.Count;
                    gvStocks.Rows[0].Cells.Clear();
                    gvStocks.Rows[0].Cells.Add(new TableCell());
                    gvStocks.Rows[0].Cells[0].ColumnSpan = columncount;
                    gvStocks.Rows[0].Cells[0].Text = "No Records Found";
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLogging.LogMessages(ex);
        }
    }


    /// <summary>
    /// Bind stock deatils 
    /// </summary>
    /// <returns></returns>
    private DataSet PopulateStocksForUser()
    {
        DataSet dsSource = null;
        try
        {
            Users user = (Users)Session["User"];

            // create user service object.
            BStock bstock = new BStock();

            // Get stocks for the given user.
            dsSource = bstock.GetStocksForGivenUser(user.Id);
        }
        catch (Exception ex)
        {
            ErrorLogging.LogMessages(ex);
        }
        return dsSource;
    }

}