﻿using CrossOver.BusinessObjects;
using CrossOver.BusinessTier;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class View_UpdateStocks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // invoke bind stocks. To bind data to grid view. 
            BindStocks();
        }
    }

    /// <summary>
    /// Bind stock details to grid view. 
    /// </summary>
    private void BindStocks()
    {
        try
        {
            // populate stocks details from database. 
            DataSet dsSource = PopulateStocksForUser();

            // Bind the stock details to gridview. 
            if (dsSource != null
                && dsSource.Tables.Count > 0
                && dsSource.Tables[0].Rows.Count > 0)
            {
                if (!dsSource.Tables[0].Rows[0]["StockName"].ToString().Equals("No records found"))
                {
                    gvStocks.DataSource = dsSource.Tables[0];
                    gvStocks.DataBind();
                }
                else
                {
                    DataTable dt = new DataTable();
                    dt.Columns.Add(new DataColumn("StockId", typeof(Int32)));
                    dt.Columns.Add(new DataColumn("StockName", typeof(string)));
                    dt.Columns.Add(new DataColumn("StockCode", typeof(string)));
                    dt.Rows.Add(dt.NewRow());
                    gvStocks.DataSource = dt;
                    gvStocks.DataBind();
                    int columncount = gvStocks.Rows[0].Cells.Count;
                    gvStocks.Rows[0].Cells.Clear();
                    gvStocks.Rows[0].Cells.Add(new TableCell());
                    gvStocks.Rows[0].Cells[0].ColumnSpan = columncount;
                    gvStocks.Rows[0].Cells[0].Text = "No Records Found";
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLogging.LogMessages(ex);
        }
    }


    /// <summary>
    /// Bind stock deatils 
    /// </summary>
    /// <returns></returns>
    private DataSet PopulateStocksForUser()
    {
        DataSet dsSource = null;
        try
        {
            Users user = (Users)Session["User"];

            // create user service object.
            BStock bstock = new BStock();

            // Get stocks for the given user.
            dsSource = bstock.GetStocksForGivenUser(user.Id);
        }
        catch (Exception ex)
        {
            ErrorLogging.LogMessages(ex);
        }
        return dsSource;
    }

    /// <summary>
    /// To handle gridview cancel events. 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        try
        {
            gvStocks.EditIndex = -1;
            BindStocks();
        }
        catch (Exception ex)
        {
            ErrorLogging.LogMessages(ex);
        }
    }


    /// <summary>
    /// To handle stock delete event. 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            string stockId = gvStocks.DataKeys[e.RowIndex].Values["StockId"].ToString();

            // create user service object. 
            BStock bStock = new BStock();

            Users user = (Users)Session["User"];

            // delete user stock.  
            bStock.DeleteUserStock(user.Id, Convert.ToInt32(stockId));

            //Bnd the latest stock data to gridview. 
            BindStocks();
        }
        catch (Exception ex)
        {
            ErrorLogging.LogMessages(ex);
        }
    }

    /// <summary>
    /// To save new stock, events are handled here. 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gridView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            // To handle add new stock details. 
            if (e.CommandName.Equals("AddNew"))
            {
                DropDownList ddlStocks = (DropDownList)gvStocks.FooterRow.FindControl("ddlStocks");
                ddlStocks.Visible = true;

                Button btnAdd = (Button)gvStocks.FooterRow.FindControl("ButtonAdd");
                btnAdd.Visible = false;
                Button btnSave = (Button)gvStocks.FooterRow.FindControl("ButtonSave");
                btnSave.Visible = true;
                Button btnCancel = (Button)gvStocks.FooterRow.FindControl("ButtonCancel");
                btnCancel.Visible = true;
            }
            // To handle save stock details. 
            else if (e.CommandName.Equals("Save"))
            {
                DropDownList ddlStocks = (DropDownList)gvStocks.FooterRow.FindControl("ddlStocks");
                Int32 selectedStock = Convert.ToInt32(ddlStocks.SelectedItem.Value);

                // Create user service object. 
                BStock bStock = new BStock();
                Users user = (Users)Session["User"];

                // Save user stock details. 
                int id = bStock.SaveUserStocks(Convert.ToInt32(user.Id), selectedStock);

                //Bind the latest data to grid view. 
                BindStocks();
            }
        }
        catch (Exception ex)
        {
            ErrorLogging.LogMessages(ex);
        }
    }

    /// <summary>
    /// To handle stock delete and data bind functionalities. 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            // To handle delete stock . 
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string stockId = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "StockId"));
                Button btnDelete = (Button)e.Row.FindControl("ButtonDelete");
                System.Web.UI.WebControls.Label lblStockName = (System.Web.UI.WebControls.Label)e.Row.FindControl("lblStockName");
                if (btnDelete != null)
                {
                    btnDelete.Attributes.Add("onclick", "javascript:return deleteConfirm('" + lblStockName.Text + "')");
                }
            }

            if (e.Row.RowType == DataControlRowType.Footer)
            {
                string stor_id = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "StockId"));
                DropDownList ddlStocks = (DropDownList)e.Row.FindControl("ddlStocks");

                if (ddlStocks != null)
                {
                    BStock bStock = new BStock();
                    List<CrossOver.BusinessObjects.Stocks> stocks = bStock.GetAllStocks();
                    ddlStocks.DataSource = stocks;
                    ddlStocks.DataTextField = "StockName";
                    ddlStocks.DataValueField = "Id";
                    ddlStocks.DataBind();
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLogging.LogMessages(ex);
        }
    }
}