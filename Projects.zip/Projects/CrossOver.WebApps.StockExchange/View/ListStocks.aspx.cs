﻿using CrossOver.BusinessTier;
using System;
using System.Collections.Generic;
using System.Data;

public partial class View_ListStocks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //Call method to populate stocks details. 
            PopulateStocks();
        }
    }

    /// <summary>
    /// To get all the stocks and save those to the grid. 
    /// </summary>
    private void PopulateStocks()
    {
        try
        {
            DataTable dtStock = new DataTable();
            DataRow drStock = null;
            dtStock.Columns.Add(new DataColumn("StockId", typeof(Int32)));
            dtStock.Columns.Add(new DataColumn("StockName", typeof(string)));
            dtStock.Columns.Add(new DataColumn("StockCode", typeof(string)));
            dtStock.Columns.Add(new DataColumn("StockPrice", typeof(string)));

            // Bind stocks,. 
            List<CrossOver.BusinessObjects.Stocks> stocks = BindStocksForUser();
            foreach (CrossOver.BusinessObjects.Stocks stock in stocks)
            {
                if (stocks != null)
                {
                    drStock = dtStock.NewRow();
                    drStock["StockId"] = stock.Id;
                    drStock["StockName"] = stock.StockName;
                    drStock["StockCode"] = stock.StockCode;
                    drStock["StockPrice"] = 1;
                    dtStock.Rows.Add(drStock);
                }
            }

            //Store the DataTable in ViewState for future reference 
            ViewState["CurrentTable"] = dtStock;

            gvStocks.DataSource = dtStock;
            gvStocks.DataBind();
        }
        catch (Exception ex)
        {
            ErrorLogging.LogMessages(ex);
        }
    }

    /// <summary>
    /// Function to bind stocks. 
    /// </summary>
    /// <returns></returns>
    private List<CrossOver.BusinessObjects.Stocks> BindStocksForUser()
    {
        List<CrossOver.BusinessObjects.Stocks> stocks = null;
        try
        {
            // create stock service object. 
            BStock bStock = new BStock();

            // Get all stocks. 
            stocks = bStock.GetAllStocks();
        }
        catch (Exception ex)
        {
            ErrorLogging.LogMessages(ex);
        }

        return stocks;
    }
}