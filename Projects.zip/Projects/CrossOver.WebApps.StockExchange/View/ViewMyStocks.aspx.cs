﻿using System;
using CrossOver.BusinessObjects;
using System.Data;
using System.Web.UI.WebControls;


public partial class View_ViewMyStocks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PopulateStocks();
        }
    }

    /// <summary>
    /// To populate all stocks. 
    /// </summary>
    private void PopulateStocks()
    {
        try
        {
            //invoke the web service to get the stock price. 
            CORS.RateService rsSource = new CORS.RateService();

            // Store logged in user data in sessin. 
            Users userObject = (Users)Session["User"];

            //Serialize user object. 
            string userData = CommonUtilities.SerialzeObject(userObject);

            //Get user stock price . 
            DataSet dsSource = rsSource.GetUserStockPrices(userData);

            if (dsSource != null
                && dsSource.Tables.Count > 0
                && dsSource.Tables[0].Rows.Count > 0)
            {
                if (!dsSource.Tables[0].Rows[0]["StockName"].ToString().Equals("No records found"))
                {// if data is found, bind it to the grid view. 
                    gvStocks.DataSource = dsSource.Tables[0];
                    gvStocks.DataBind();
                }
                else
                {
                    // if no data is found, then provide the user with an option to choose the stock. 
                    DataTable dtStock = new DataTable();
                    dtStock.Columns.Add(new DataColumn("StockId", typeof(Int32)));
                    dtStock.Columns.Add(new DataColumn("StockName", typeof(string)));
                    dtStock.Columns.Add(new DataColumn("StockCode", typeof(string)));
                    dtStock.Columns.Add(new DataColumn("StockPrice", typeof(string)));

                    dtStock.Rows.Add(dtStock.NewRow());
                    gvStocks.DataSource = dtStock;
                    gvStocks.DataBind();
                    int columncount = gvStocks.Rows[0].Cells.Count;
                    gvStocks.Rows[0].Cells.Clear();
                    gvStocks.Rows[0].Cells.Add(new TableCell());
                    gvStocks.Rows[0].Cells[0].ColumnSpan = columncount;
                    gvStocks.Rows[0].Cells[0].Text = "No Records Found";
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLogging.LogMessages(ex);
        }
    }
}