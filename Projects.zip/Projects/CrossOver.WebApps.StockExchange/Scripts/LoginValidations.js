﻿$(function () {
    
    // when we open this through modaldialog then the argument what we sent that will be retrieved here
    // document.title = window.dialogArguments;

    // get the benchmarkvalue text box object        
    var input = $('#ContentPlaceHolder1_txtUserName');

    // attach the key press event to handle to allow 
    // only alphanumeric data in the textbox
    input.bind('keypress', function (e) {        
        // define the regular expression what data need to be allowed
        // numbers, letters small and capital and space
        var regex = new RegExp("^[a-zA-Z0-9]+$");

        // identify the charcode of each key press to identify
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);

        // if the key pressed form the above list allow to textbox
        if (regex.test(str)) {
            // allow the key to textbox
            return true;
        }

        // if the key pressed is not in the above list restrict it.
        e.preventDefault();

        // exceept the above list values do not allow them to the textbox
        return false;
    });
       
    // get the benchmarkvalue text box object        
    var input = $('#ContentPlaceHolder1_txtPassword');

    // attach the key press event to handle to allow 
    // only alphanumeric data in the textbox
    input.bind('keypress', function (e) {

        // define the regular expression what data need to be allowed
        // numbers, letters small and capital and space
        var regex = new RegExp("^[a-zA-Z0-9]+$");

        // identify the charcode of each key press to identify
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);

        // if the key pressed form the above list allow to textbox
        if (regex.test(str)) {
            // allow the key to textbox
            return true;
        }

        // if the key pressed is not in the above list restrict it.
        e.preventDefault();

        // exceept the above list values do not allow them to the textbox
        return false;
    });
    
    // validate the textbox to input some data, 
    // if not display amessaget to user to correct it
    $("#ContentPlaceHolder1_btnLogin").click(function () {
        
        var txtUserName = $("#ContentPlaceHolder1_txtUserName").val();
        var txtPassword = $("#ContentPlaceHolder1_txtPassword").val();

        var errMessageFinal = '';
        var isValid = true;
        
        // if the textbox length is 0
        if (txtUserName.length == 0) {

            errMessageFinal = errMessageFinal + "</br>" + "User name must be entered.";

            // do not take any action
            isValid = false;
        }

        // if the textbox length is 0
        if (txtPassword.length == 0) {

            errMessageFinal = errMessageFinal + "</br>" + "Password must be entered.";

            // do not take any action
            isValid = false;
        }              

        if (!isValid) {
            // display error message
            DisplayMessage1(errMessageFinal, true, true);            
        }

        // allow proceed to further actions
        return isValid;
    });


});

// isDisplay : true / false
// messageType : validation / information 
function DisplayMessage(msgToDisplay, isDisplay, messageType) {
    $("#ContentPlaceHolder1_lblUserMsg").html(msgToDisplay);

    if (isDisplay) {
        // display the message
        $("#ContentPlaceHolder1_lblUserMsg").css("display", "block");
    }
    else {
        // Hide the message
        $("#ContentPlaceHolder1_lblUserMsg").css("display", "none");
    }

    if (messageType == "validation") {
        // display validation messages with red color
        $("#ContentPlaceHolder1_lblUserMsg").css("color", "#FF0000")
    }
    else if (messageType == "information") {
        // display information messages with green color
        $("ContentPlaceHolder1_#lblUserMsg").css("color", "#008000")
    }
}

function DisplayMessage1(msgToDisplay, isDisplay, isValidationType) {

    var errorTypeDsisplay = '';

    if (isValidationType) {
        errorTypeDsisplay = 'validation';
    }
    else {
        errorTypeDsisplay = 'information';
    }

    DisplayMessage(msgToDisplay, isDisplay, errorTypeDsisplay);
}