﻿        function deleteConfirm(pubid) {
            var result = confirm('Do you want to delete "' + pubid + '"?');
            if (result) {
                return true;
            }
            else {
                return false;
            }
        }
