﻿using CrossOver.BusinessObjects;
using CrossOVer.DataAccessTier.DAServices;
using System;
using System.Collections.Generic;
using System.Data;

/*******************************************************************************************************************
  * Created By:: Totada
  * Create Date:: 14th April
  * Last Modified By: Totada 
  * Puropose:: Business stock layer
  *
  *******************************************************************************************************************/
  
namespace CrossOver.BusinessTier
{
    public class BStock
    {
        // instantiate stock service.
        DAStockServices stockService = null;

        public BStock()
        {
            stockService = new DAStockServices();
        }

        /// <summary>
        /// To get the stocks for the given user. 
        /// </summary>
        /// <param name="currentUserid"></param>
        /// <returns></returns>
        public DataSet GetStocksForGivenUser(int currentUserid)
        {
            try
            {
                return stockService.GetStocksForGivenUser(currentUserid);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// To get all the stocks.
        /// </summary>
        /// <returns></returns>
        public List<Stocks> GetAllStocks()
        {
            try
            {
                return stockService.GetAllStocks();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Save stock. 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="stockId"></param>
        /// <returns></returns>
        public int SaveUserStocks(int userId, int stockId)
        {
            int idResult;
            try
            {
                return idResult = stockService.SaveUserStocks(userId, stockId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Delete stocks. 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="stockId"></param>
        /// <returns></returns>
        public bool DeleteUserStock(int userId, int stockId)
        {
            bool deleteStatus;
            try
            {
                deleteStatus = stockService.DeleteUserStock(userId, stockId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return deleteStatus;
        }
    }
}
