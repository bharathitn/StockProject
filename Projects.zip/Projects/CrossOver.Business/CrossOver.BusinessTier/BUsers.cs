﻿using CrossOver.BusinessObjects;
using CrossOVer.DataAccessTier.DAServices;
using System;
using System.Data;


/*******************************************************************************************************************
  * Created By:: Totada
  * Create Date:: 14th April
  * Last Modified By: Totada 
  * Puropose:: Business user layer
  *
  *******************************************************************************************************************/
  
namespace CrossOver.BusinessTier
{
    public class BUsers
    {
        // instantiate user service. 
        DAUserServices userService = null;

        public BUsers()
        {
            userService = new DAUserServices();
        }

        /// <summary>
        /// To get all the users. 
        /// </summary>
        /// <returns></returns>
        public DataSet GetUsers()
        {
            try
            {
                return userService.GetUsers();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// To register the new user. 
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public string RegisterUsers(Users user)
        {
            string resultStatus = string.Empty;
            try
            {
                resultStatus = Convert.ToString(userService.RegisterUsers(user));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return resultStatus;
        }

        /// <summary>
        /// To validate the user.
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public DataSet AuthenticateUser(Users user)
        {
            try
            {
                return userService.AuthenticateUser(user);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Delete the user. 
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public string DeleteUser(Users user)
        { 
            try
            {
                return userService.DeleteUsers(user.Id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int GetUserId(Users user)
        {
            try
            {
                return userService.GetUserId(user.UserName, user.Password);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
