﻿
using System;
using System.Data;
using System.Configuration;

public enum LoggingType
{
    Debug,
    Error
}

public class ErrorLogging
{
    /// <summary>
    /// Log the messages by passing the information with formated manually like classs and method names,
    /// this method is obsolete instead use  "LogMessages(ByVal stackTrace As System.Diagnostics.StackTrace, ByVal logTypeSource As LoggingType, ByVal messageSource As String)"
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="logTypeSource"></param>
    /// <param name="messageSource"></param>
    /// <remarks></remarks>
    public static void LogMessages<T>(LoggingType logTypeSource, string messageSource) where T : class
    {
        CreateLog(typeof(T).FullName, messageSource, logTypeSource.ToString().ToUpper());
    }

    /// <summary>
    /// Log the messages by passing the information with the type of the object using reflecitons,
    /// this method is obsolete instead use  "LogMessages(ByVal stackTrace As System.Diagnostics.StackTrace, ByVal logTypeSource As LoggingType, ByVal messageSource As String)"
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="stackTrace"></param>
    /// <param name="logTypeSource"></param>
    /// <param name="messageSource"></param>
    /// <remarks></remarks>
    public static void LogMessages<T>(System.Diagnostics.StackTrace stackTrace, LoggingType logTypeSource, string messageSource) where T : class
    {
        CreateLog(string.Format("{0} [({1})]", typeof(T).FullName, stackTrace.GetFrames()[0].GetMethod().Name), messageSource, logTypeSource.ToString().ToUpper());
    }

    /// <summary>
    /// Log the messages by passing the information with the stack trace
    /// </summary>
    /// <param name="stackTrace">stack trace information to get extract the class and method names</param>
    /// <param name="logTypeSource">LogType source like Error/Debug</param>
    /// <param name="messageSource">Messaeg to be logged</param>
    /// <remarks>returns nothing</remarks>
    public static void LogMessages(System.Diagnostics.StackTrace stackTrace, LoggingType logTypeSource, string messageSource)
    {
        CreateLog(string.Format("{0} [({1})]", stackTrace.GetFrames()[0].GetMethod().ReflectedType.FullName, stackTrace.GetFrames()[0].GetMethod().Name), messageSource, logTypeSource.ToString().ToUpper());
    }

    /// <summary>
    /// Log the exception messages by passing the exception object
    /// </summary>
    /// <param name="exSource">Exception objects a source</param>
    /// <remarks>returns nothing</remarks>
    public static void LogMessages(Exception exSource)
    {
        System.Diagnostics.StackTrace stackTraceSource = new System.Diagnostics.StackTrace(exSource);

        CreateLog(string.Format("{0} [({1})]", stackTraceSource.GetFrames()[0].GetMethod().ReflectedType.FullName, stackTraceSource.GetFrames()[0].GetMethod().Name), string.Format("Exception: {0}", exSource.Message), LoggingType.Error.ToString().ToUpper());

        CreateLog(string.Format("{0} [({1})]", stackTraceSource.GetFrames()[0].GetMethod().ReflectedType.FullName, stackTraceSource.GetFrames()[0].GetMethod().Name), string.Format("StackTrace: {0}", exSource.StackTrace), LoggingType.Error.ToString().ToUpper());
    }

    /// <summary>
    /// Create log file.
    /// </summary>
    /// <param name="title">Title or source of the page.</param>
    /// <param name="msg">Message to be logged.</param>
    /// <returns>returns nothing.</returns>
    private static void CreateLog(string title, string msg, string logType)
    {
        string isLogstobeEnabled = ConfigurationSettings.AppSettings["ErrorLog_ToBeLogged"];

        if (Convert.ToBoolean(isLogstobeEnabled))
        {
            WriteLog(title, msg, logType);
        }

    }
    /// <summary>
    /// Create log file.
    /// </summary>
    /// <param name="title">Title or source of the page.</param>
    /// <param name="msg">Message to be logged.</param>
    /// <returns>returns nothing.</returns>
    private static void WriteLog(string title, string msg, string logType)
    {
        try
        {
            string filePath = ConfigurationSettings.AppSettings["ErrorLog_Path"];
            string logFileName = ConfigurationSettings.AppSettings["ErrorLog_Prefix_FileName"];

            filePath = string.Concat(filePath, (Convert.ToString(logFileName)), System.DateTime.Today.ToString("-dd-MM-yyyy"), ".", "log");

            using (System.IO.StreamWriter file1 = new System.IO.StreamWriter(filePath, true))
            {
                file1.WriteLine(string.Format("{0} {1} {2} - {3}", DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss,fff"), logType, title, msg));
            }

        }
        catch (Exception ex)
        {
            WriteLog(title, ex.Message, logType);
            WriteLog(title, ex.StackTrace, logType);
        }
    }

    /// <summary>
    /// Evalute the string expressions.
    /// </summary>
    /// <param name="expr">Expresiion as string value.</param>
    /// <returns><c>true</c> if condition satisfies, <c>false</c> otherwise.</returns>
    public static object EvaluateStringExpression(string expr)
    {
        bool result = false;
        DataTable dtSource = new DataTable();
        try
        {
            result = Convert.ToBoolean(dtSource.Compute(expr, null));
        }
        catch (Exception ex)
        {
            ErrorLogging.LogMessages((new System.Diagnostics.StackTrace()), LoggingType.Error, string.Format("Exception occurred when evaluating the expression: {0}", expr));
            ErrorLogging.LogMessages(ex);

            result = false;
        }

        return result;
    }
}
